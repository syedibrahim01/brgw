#!/bin/bash
########################################
#Scrit: LOGSTASH_install.sh
#Autor: Vani Singamsetty
#Date: 08/17/2022 First Draft
#Date: 09/06/2022 Added deploy props
########################################


STEP="LOGSTASH INSTALLATIOn START"
trap onerr ERR

function onerr() {
    RC=$?
    CHECKPOINT=$(date -u '+%FT%H:%M:%SZ')
    echo "${CHECKPOINT} LOGSTASH installation failed during $STEP with code $RC"
    exit $RC
}

function abort() {
    RETVAL=$1
    shift
    date -u "+%FT%H:%M:%SZ"
    echo "ABORT: $*"
    exit ${RETVAL}
}

function prechecks() {

    date -u "+%FT%H:%M:%SZ"
    echo "##############################################"
    echo "############## Perform prechecks #############"
    echo "##############################################"

    RETVAL=1


    if cat /etc/*release | grep ^NAME | grep CentOS; then
        LS_EXE=logstash-${LS_VERSION}-x86_64.rpm
        INSTALL_BIN=`which rpm`
    elif cat /etc/*release | grep ^NAME | grep Red; then
        LS_EXE=logstash-${LS_VERSION}-x86_64.rpm
        INSTALL_BIN=`which rpm`
    elif cat /etc/*release | grep ^NAME | grep Fedora; then
        LS_EXE=logstash-${LS_VERSION}-x86_64.rpm
        INSTALL_BIN=`which rpm`
    elif cat /etc/*release | grep ^NAME | grep Ubuntu; then
        LS_EXE=logstash-${LS_VERSION}-amd64.deb
        INSTALL_BIN=`which apt`
    elif cat /etc/*release | grep ^NAME | grep Debian ; then
        LS_EXE=logstash-${LS_VERSION}-amd64.deb
        INSTALL_BIN=`which apt`
    fi


    RETVAL=0
    return ${RETVAL}

}

function setup_exists() {

    date -u "+%FT%H:%M:%SZ"
    echo "##############################################"
    echo "########## Validate existing intallation #####"
    echo "##############################################"

    RETVAL=1

    if [[ -e $LS_BIN_HOME/logstash ]]; then
        abort 0 "logstash setup already exists in $LS_BIN_HOME with configs $LS_CONFIG"
    fi

    RETVAL=0
    return ${RETVAL}

}

function install() {

    date -u "+%FT%H:%M:%SZ"
    echo "###########################################i#############"
    echo "########## Install logstash ######################"
    echo "#########################################################"

    RETVAL=1

    cd $BASEDIR

    if [[ "${BA_PROXY:-}x" != "x" ]]; then
        HTTP_PROXY="${BA_PROXY}"; export HTTP_PROXY
        HTTPS_PROXY="${BA_PROXY}"; export HTTPS_PROXY
    fi

    curl -k -O ${LS_ARTIFACT_URL}/${LS_EXE}

    if [[ ! -f "${BASEDIR}/${LS_EXE}" ]]; then
      abort 1 "$LS_EXE failed to download."
    fi

    if [[ "${LS_EXE}" =~ .*"rpm".* ]]; then
       yes | sudo rpm -ivh ${BASEDIR}/${LS_EXE}
       #sudo chkconfig --add logstash || abort $? "sudo chkconfig --add logstash failed."
    elif [[ "${LS_EXE}" =~ .*"deb".* ]]; then
       sudo apt install ${BASEDIR}/${LS_EXE}
    fi

    if [[ -e $LS_BIN_HOME/logstash ]]; then
        sudo systemctl enable logstash
    else
        abort 1 "logstash failed to install!!"
    fi

    RETVAL=0
    return ${RETVAL}

}

function config() {

  mkdir -p $LS_DATA_PATH/logs/logstash
  mkdir -p $LS_DATA_PATH/logstash_data
  mkdir -p $LS_CONF_HOME/conf.d

  #$LS_BIN_HOME/logstashlogstash keystore create -c $LS_CONFIG
  #echo 'LOGSTASH' | $LS_BIN_HOME/logstash keystore add LS_USER --force -c $LS_CONFIG
  #echo 'bitnami' | $LS_BIN_HOME/logstash keystore add LS_PWD --force -c $LS_CONFIG

  if [[ -f $LS_CONFIG ]]; then
    mv $LS_CONFIG $LS_CONFIG.orignal
    mv $LS_CONF_HOME/jvm.options $LS_CONF_HOME/jvm.options.original
    mv $LS_CONF_HOME/log4j2.properties $LS_CONF_HOME/log4j2.properties.original
  fi

  cp -r $BASEDIR/logstash_configs/logstash.yml $LS_CONF_HOME/
  cp -r $BASEDIR/logstash_configs/jvm.options $LS_CONF_HOME/
  cp -r $BASEDIR/logstash_configs/log4j2.properties $LS_CONF_HOME/
  cp -r $BASEDIR/logstash_configs/service_lookup.csv $LS_CONF_HOME/
  cp -r $BASEDIR/logstash_configs/*.conf $LS_CONF_HOME/conf.d/
  cp -r $BASEDIR/certs/*.pem $LS_CONF_HOME/

  ## USer setup
  export LOGSTASH_KEYSTORE_PASS=$LS_KEYSTORE_PASS
  $LS_BIN_HOME/logstash-keystore --path.settings $LS_CONF_HOME create || abort $? "Failed to create logstash keystore"
  printf "$LS_USER" | $LS_BIN_HOME/logstash-keystore --path.settings $LS_CONF_HOME add "LS_USER" || abort $? "Failed to add ls_user in keystore"
  printf "$LS_PASS" | $LS_BIN_HOME/logstash-keystore --path.settings $LS_CONF_HOME add "LS_PASS" || abort $? "Failed to add ls_pass in keystore"

  mkdir -p /etc/sysconfig
  echo "LOGSTASH_KEYSTORE_PASS=$LS_KEYSTORE_PASS" >> /etc/sysconfig/logstash

  chmod 777 $LS_DATA_PATH
  chmod 777 $LS_DATA_PATH/logs
  chmod 777 $LS_DATA_PATH/logs/logstash
  chown -R $LS_USER:$LS_GROUP $LS_DATA_PATH/logstash_data
  chown -R $LS_USER:$LS_GROUP $LS_DATA_PATH/logs/logstash
  #chmod 777 $LS_DATA_PATH/logs
  #chown $LS_USER:$LS_GROUP $LS_DATA_PATH/logstash
  #chown $LS_USER:$LS_GROUP $LS_DATA_PATH/logs/logstash
  chown -R $LS_USER:$LS_GROUP $LS_CONF_HOME



}


function start_process() {

    RETVAL=1

    sudo systemctl start logstash
    sleep 3
    LS_RUNNIG_STATUS=$(sudo systemctl status logstash | tail -1 | grep Started | wc -l)
    if [[$LS_RUNNIG_STATUS == 0 ]]; then
        abort 1 "logstash failed to start process, please check manually.."
    else
       echo "###### logstash started successfully."
    fi
    RETVAL=0
    return ${RETVAL}

}

function install_plugins() {

      $LS_BIN_HOME/logstash-plugin install  logstash-filter-aggregate || abort $? "Failed to install  logstash-filter-aggregate plugin"
      $LS_BIN_HOME/logstash-plugin install logstash-filter-translate || abort $? "Failed to install   logstash-filter-translate plugin"

}


####################### HERE MAIN ##################

set -x
set +e
set -o pipefail

RETVAL=0

export BASEDIR=$( cd $( /usr/bin/dirname $0 ) > /dev/null 2>&1; pwd )

source $BASEDIR/deployment.props

STEP="PERFORM PRECHECKS"
prechecks

STEP="VALIDATE logstash EXISTING INSTALLATION"
setup_exists

STEP="INSTALL logstash"
install

STEP="CONFIGURE logstash"
config

STEP="INSTALL PLUGINS"
install_plugins

STEP="START logstash"
start_process

sleep 20

STEP="REMOVE TMP FILES"
rm -rf $BASEDIR/${LS_EXE}

echo "######## Completed the logstash installaion. ##########"

exit ${RETVAL}
