#!/bin/bash
##################################################
#Scrit: elastic_install.sh
#Autor: Vani Singamsetty
# Version: 1.1 Date: 08/17/2022
# Version: 1.2 Date: 09/06/2022 Added deploy props
###################################################


STEP="ELASTIC INSTALLATIOn START"
trap onerr ERR

function onerr() {
    RC=$?
    CHECKPOINT=$(date -u '+%FT%H:%M:%SZ')
    echo "${CHECKPOINT} ELASTIC installation failed during $STEP with code $RC"
    exit $RC
}

function abort() {
    RETVAL=$1
    shift
    date -u "+%FT%H:%M:%SZ"
    echo "ABORT: $*"
    exit ${RETVAL}
}

function prechecks() {

    date -u "+%FT%H:%M:%SZ"
    echo "##############################################"
    echo "############## Perform prechecks #############"
    echo "##############################################"

    RETVAL=1


    if cat /etc/*release | grep ^NAME | grep CentOS; then
        ES_EXE=elasticsearch-${ES_VERSION}-x86_64.rpm
        INSTALL_BIN=`which rpm`
    elif cat /etc/*release | grep ^NAME | grep Red; then
        ES_EXE=elasticsearch-${ES_VERSION}-x86_64.rpm
        INSTALL_BIN=`which rpm`
    elif cat /etc/*release | grep ^NAME | grep Fedora; then
        ES_EXE=elasticsearch-${ES_VERSION}-x86_64.rpm
        INSTALL_BIN=`which rpm`
    elif cat /etc/*release | grep ^NAME | grep Ubuntu; then
        ES_EXE=elasticsearch-${ES_VERSION}-amd64.deb
        INSTALL_BIN=`which apt`
    elif cat /etc/*release | grep ^NAME | grep Debian ; then
        ES_EXE=elasticsearch-${ES_VERSION}-amd64.deb
        INSTALL_BIN=`which apt`
    fi


    RETVAL=0
    return ${RETVAL}

}

function setup_exists() {

    date -u "+%FT%H:%M:%SZ"
    echo "##############################################"
    echo "########## Validate existing intallation #####"
    echo "##############################################"

    RETVAL=1

    if [[ -e $ES_BIN_HOME/elasticsearch ]]; then
        abort 0 "elasticsearch setup already exists in $ES_BIN_HOME with configs $ES_CONFIG"
    fi

    RETVAL=0
    return ${RETVAL}

}

function install() {

    date -u "+%FT%H:%M:%SZ"
    echo "###########################################i#############"
    echo "########## Install elasticsearch ######################"
    echo "#########################################################"

    RETVAL=1

    cd $BASEDIR

    if [[ "${BA_PROXY:-}x" != "x" ]]; then
        HTTP_PROXY="${BA_PROXY}"; export HTTP_PROXY
        HTTPS_PROXY="${BA_PROXY}"; export HTTPS_PROXY
    fi

    curl -k -O ${ES_ARTIFACT_URL}/${ES_EXE}

    if [[ ! -f "${BASEDIR}/${ES_EXE}" ]]; then
      abort 1 "$ES_EXE failed to download."
    fi

    if [[ "${ES_EXE}" =~ .*"rpm".* ]]; then
       yes | sudo rpm -ivh ${BASEDIR}/${ES_EXE}
       #sudo chkconfig --add elasticsearch || abort $? "sudo chkconfig --add elasticsearch failed."
    elif [[ "${ES_EXE}" =~ .*"deb".* ]]; then
       sudo apt install ${BASEDIR}/${ES_EXE}
    fi

    if [[ -e $ES_BIN_HOME/elasticsearch ]]; then
        sudo systemctl enable elasticsearch
    else
        abort 1 "elasticsearch failed to install!!"
    fi

    RETVAL=0
    return ${RETVAL}

}

function config() {

  mkdir -p ${ES_DATA_PATH}/logs/elasticsearch
  mkdir -p ${ES_DATA_PATH}/elastic_data

  #$ES_BIN_HOME/elasticsearchelasticsearch keystore create -c $ES_CONFIG
  #echo 'elastic' | $ES_BIN_HOME/elasticsearch keystore add ES_USER --force -c $ES_CONFIG
  #echo 'bitnami' | $ES_BIN_HOME/elasticsearch keystore add ES_PWD --force -c $ES_CONFIG

  if [[ -f $ES_CONFIG ]]; then
    mv $ES_CONFIG $ES_CONFIG.orignal
    mv $ES_CONF_HOME/jvm.options $ES_CONF_HOME/jvm.options.original
    mv $ES_CONF_HOME/log4j.properties $ES_CONF_HOME/log4j.properties.original
  fi

  cp -r $BASEDIR/elastic_configs/elasticsearch.yml $ES_CONF_HOME/
  cp -r $BASEDIR/elastic_configs/jvm.options $ES_CONF_HOME/
  cp -r $BASEDIR/elastic_configs/log4j.properties $ES_CONF_HOME/
  cp -r $BASEDIR/certs/*.pem $ES_CONF_HOME/

  ## USer setup
  printf "$ES_BOOT_PASS" | $ES_BIN_HOME/elasticsearch-keystore add "bootstrap.password" || abort $? "Failed to add bootstrap.password"

}


function start_process() {

    RETVAL=1

    chmod 777 ${ES_DATA_PATH}
    chmod 777 ${ES_DATA_PATH}/logs
    chmod 777 ${ES_DATA_PATH}/logs/elasticsearch
    chown -R $ES_USER:$ES_GROUP ${ES_DATA_PATH}/elastic_data
    chown -R $ES_USER:$ES_GROUP ${ES_DATA_PATH}/logs/elasticsearch
    #chmod 777 ${ES_DATA_PATH}/logs
    #chown $ES_USER:$ES_GROUP ${ES_DATA_PATH}/elastic
    #chown $ES_USER:$ES_GROUP ${ES_DATA_PATH}/logs/elasticsearch
    chown -R $ES_USER:$ES_GROUP $ES_CONF_HOME

    sudo systemctl start elasticsearch
    sleep 3
    ES_RUNNIG_STATUS=$(sudo systemctl status elasticsearch | tail -1 | grep Started | wc -l)
    if [[$ES_RUNNIG_STATUS == 0 ]]; then
        abort 1 "elasticsearch failed to start process, please check manually.."
    else
       echo "###### elasticsearch started successfully."
    fi
    RETVAL=0
    return ${RETVAL}

}

function install_plugins() {

      $ES_BIN_HOME/elasticsearch-plugin install mapper-size || abort $? "Failed to install mapper plugin"
      $ES_BIN_HOME/elasticsearch-plugin install repository-azure || abort $? "Failed to install repository-azure"

}

function user_addition() {

	RETVAL=1

	curl -k -u "elastic:$ES_BOOT_PASS" -XPUT -H 'Content-Type: application/json' 'http://localhost:9200/_security/user/kibana_system/_password?pretty' -d '{ "password":"kibana_system" }'
   	curl -k -u "elastic:$ES_BOOT_PASS" -XPUT -H 'Content-Type: application/json' 'http://localhost:9200/_security/user/kibana/_password?pretty' -d '{ "password":"AZkibana2k22" }'
	curl -k -u "elastic:$ES_BOOT_PASS" -XPUT -H 'Content-Type: application/json' 'http://localhost:9200/_security/user/logstash_system/_password?pretty' -d '{ "password":"logstash_system" }'
	curl -k -u "elastic:$ES_BOOT_PASS" -XPUT -H 'Content-Type: application/json' 'http://localhost:9200/_security/user/apm_system/_password?pretty' -d '{ "password":"apm_system" }'
	curl -k -u "elastic:$ES_BOOT_PASS" -XPUT -H 'Content-Type: application/json' 'http://localhost:9200/_security/user/remote_monitoring_user/_password?pretty' -d '{ "password":"remote_monitoring_user"  }'

    curl -k -u "elastic:$ES_BOOT_PASS" -XPUT -H 'Content-Type: application/json' 'http://localhost:9200/_security/role/bluearmor_logstash' -d '{ "cluster" : ["manage_logstash_pipelines", "monitor","monitor_rollup","monitor_transform","monitor_snapshot"], "indices" : [ {"names" : ["bluearmor*","catalina*","metricbeat*","auditbeat*","filebeat*","heartbeat*", ".monitoring*"],"privileges" : [ "read","write","view_index_metadata","create","create_index","create_doc", "manage"], "allow_restricted_indices" : false} ],"applications" : [ ],"run_as" : [ ],"transient_metadata" : {"enabled" : true} }'
    curl -k -u "elastic:$ES_BOOT_PASS" -XPUT -H 'Content-Type: application/json' 'http://localhost:9200/_security/role/bluearmor_rw' -d '{ "cluster" : ["manage_logstash_pipelines", "monitor","monitor_rollup","monitor_transform","monitor_snapshot"], "indices" : [ {"names" : ["bluearmor*","metricbeat*","auditbeat*","filebeat*","heartbeat*",".monitoring*",".kibana*"],"privileges" : [ "read","write","view_index_metadata" ], "allow_restricted_indices" : false} ],"applications" : [ { "application" : "kibana-.kibana", "privileges" : [ "space_all" ], "resources" : [ "space:bluearmor" ] } ],"run_as" : [ ],"transient_metadata" : {"enabled" : true} }'
    curl -k -u "elastic:$ES_BOOT_PASS" -XPUT -H 'Content-Type: application/json' 'http://localhost:9200/_security/role/bluearmor_ro' -d '{ "cluster" : ["monitor"], "indices" : [ {"names" : ["bluearmor*","metricbeat*","auditbeat*","filebeat*","heartbeat*",".monitoring*",".kibana*"],"privileges" : [ "read","view_index_metadata"], "allow_restricted_indices" : false} ],"applications" : [ { "application" : "kibana-.kibana", "privileges" : [ "space_read" ], "resources" : [ "space:bluearmor" ] } ],"run_as" : [ ],"transient_metadata" : {"enabled" : true} }'
    curl -k -u "elastic:$ES_BOOT_PASS" -XPUT -H 'Content-Type: application/json' 'http://localhost:9200/_security/role/catalina_rw' -d '{ "cluster" : ["manage_logstash_pipelines", "monitor","monitor_rollup","monitor_transform","monitor_snapshot"], "indices" : [ {"names" : ["catalina*",".kibana*"],"privileges" : [ "read","write","view_index_metadata" ], "allow_restricted_indices" : false} ],"applications" : [ { "application" : "kibana-.kibana", "privileges" : [ "space_all" ], "resources" : [ "space:catalina" ] } ],"run_as" : [ ],"transient_metadata" : {"enabled" : true} }'
    curl -k -u "elastic:$ES_BOOT_PASS" -XPUT -H 'Content-Type: application/json' 'http://localhost:9200/_security/role/catalina_ro' -d '{ "cluster" : ["monitor"], "indices" : [ {"names" : ["catalina*",".kibana*"],"privileges" : [ "read","view_index_metadata"], "allow_restricted_indices" : false} ],"applications" : [ { "application" : "kibana-.kibana", "privileges" : [ "space_read" ], "resources" : [ "space:catalina" ] } ],"run_as" : [ ],"transient_metadata" : {"enabled" : true} }'

    curl -k -u "elastic:$ES_BOOT_PASS" -XPUT -H 'Content-Type: application/json' http://localhost:9200/_security/user/${ES_LOGSTASH_USER}?pretty -d '{ "password":"'"${ES_LOGSTASH_PASS}"'", "roles":[ "bluearmor_logstash", "beats_admin", "ingest_admin", "enrich_user", "monitoring_user", "remote_monitoring_agent", "remote_monitoring_collector" ] }'
    curl -k -u "elastic:$ES_BOOT_PASS" -XPUT -H 'Content-Type: application/json' http://localhost:9200/_security/user/${ES_GATEWAY_USER}?pretty -d '{ "password":"'"${ES_GATEWAY_PASS}"'", "roles":[ "bluearmor_rw" ] }'
    curl -k -u "elastic:$ES_BOOT_PASS" -XPUT -H 'Content-Type: application/json' http://localhost:9200/_security/user/${ES_CATALINA_USER}?pretty -d '{ "password":"'"${ES_CATALINA_PASS}"'", "roles":[ "catalina_rw" ] }'


	RETVAL=0
	return ${RETVAL}

}


####################### HERE MAIN ##################

set -x
set +e
set -o pipefail

RETVAL=0

export BASEDIR=$( cd $( /usr/bin/dirname $0 ) > /dev/null 2>&1; pwd )

source $BASEDIR/deployment.props

STEP="PERFORM PRECHECKS"
prechecks

STEP="VALIDATE elasticsearch EXISTING INSTALLATION"
setup_exists

STEP="INSTALL elasticsearch"
install

STEP="CONFIGURE elasticsearch"
config

STEP="INSTALL PLUGINS"
install_plugins

STEP="START elasticsearch"
start_process

sleep 60

STEP="START USER CREATION"
user_addition

STEP="REMOVE TMP FILES"
rm -rf $BASEDIR/${ES_EXE}

echo "######## Completed the elasticsearch installaion. ##########"

exit ${RETVAL}
